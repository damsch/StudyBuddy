
//Ressources:
//https://stackoverflow.com/questions/2560784/how-to-center-elements-in-the-boxlayout-using-center-of-the-element

import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class mainGUI extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private FlowLayout layout = new FlowLayout();
	JLabel title = new JLabel("Note taker");
	JButton addFile = new JButton("Import file");
	
	//public static void main(String[] args) {
	//	new mainGUI();
	//}
	
	/**
	 * Constructor of the mainGUI, containing all the parts of the GUI
	 */
	
	public mainGUI() {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		this.setSize(width, height);
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
		
		//a class for each part of the GUI, makes things easier
		//ListCoursesGUI gui1 = new ListCoursesGUI();
		//CoursesGUI gui2 = new CoursesGUI();
		//SummaryGUI gui3 = new SummaryGUI();
		
		title.setFont(new Font("Arial", Font.BOLD, 25));
		title.setForeground(Color.DARK_GRAY);
		
		this.add(title);
		//this.add(addFile);
		title.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		//global panel will contain gui1 and newPanel (containing gui2 and gui3)
		JPanel globalPanel = new JPanel();
		globalPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		layout.setAlignment(FlowLayout.LEADING);
        layout.setHgap(width/10);
		globalPanel.setLayout(layout);
		globalPanel.add(addFile);
		//globalPanel.add(gui1);
		
		//newPanel contains gui2 and gui3
		JPanel newPanel = new JPanel();
		GridLayout theLayout = new GridLayout(0,1);
		theLayout.setVgap(height/13);
		newPanel.setLayout(theLayout);
		//newPanel.add(gui2);
		//newPanel.add(gui3);
		
		globalPanel.add(newPanel);
		this.add(globalPanel);
		this.setLocationRelativeTo(null);
		pack();
		setVisible(true);
	}

}
