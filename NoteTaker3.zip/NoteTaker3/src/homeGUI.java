import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JSlider;

import com.google.cloud.language.v1.Entity;

public class homeGUI extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private FlowLayout layout = new FlowLayout();
	JLabel title = new JLabel("StudyBuddy");
	JButton addFileButton = new JButton("Import file...");
	JButton exportButton = new JButton("Export");
	JTextArea textArea = new JTextArea();
	JScrollPane scroll = new JScrollPane(textArea);
	Analyzer theAnalyzer = new Analyzer();
	String text = "";
	String summary = "";
	String fillBlanksS = "";
	static ArrayList<String> listQuestions;
	double ratio = 0.4;
	
	public homeGUI() {
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		this.setSize(width, height);
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        
        title.setFont(new Font("Arial", Font.BOLD, 25));
		title.setForeground(Color.DARK_GRAY);
		
		this.add(title);
		title.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		JPanel globalPanel = new JPanel();
		globalPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		layout.setAlignment(FlowLayout.CENTER);
        layout.setHgap(width/10);
		globalPanel.setLayout(layout);
		//globalPanel.add(addFileButton);
		
		addFileButton.setActionCommand("add");
		addFileButton.addActionListener(new ButtonListener());
		
		exportButton.setActionCommand("export");
		exportButton.addActionListener(new ButtonListener());
		
		textArea.setLineWrap(true);
		
		JSlider slider = new JSlider();   

        //slider.setLayout(new FlowLayout(1, 100, 200));
        slider.setMajorTickSpacing(5);
        slider.setPaintTicks(true);
        slider.setSize(200, 200);
        slider.setVisible(true);
        
        slider.addChangeListener(new ChangeListener(){
            public void stateChanged(ChangeEvent e) {
                ratio = slider.getValue()/100.0;
                fillBlanks();
                fillTextArea();
            }
        });
		
		//this.add(globalPanel);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addFileButton);
        buttonPanel.add(exportButton);
        buttonPanel.add(slider);
        this.add(buttonPanel);
		//this.add(slider);
		this.add(scroll);
		//this.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 500));
		this.setLocationRelativeTo(null);
		ImageIcon img = new ImageIcon("logo.png");
		this.setIconImage(img.getImage());
		Image icon = Toolkit.getDefaultToolkit().getImage("logo.png");
	    this.setIconImage(icon);
		pack();
		setVisible(true);
		
	}
	
	public void fillTextArea() {
		textArea.setText("--- STUDY GUIDE ---");
		textArea.append("\n");
		textArea.append("\n");
		textArea.append("SUMMARY");
		textArea.append("\n");
		textArea.append(summary);
		textArea.append("\n");
		textArea.append("\n");
		textArea.append("QUESTIONS");
		textArea.append("\n");
		for (int i = 0;i<listQuestions.size();i++) {
			textArea.append((i+1) + " - " + listQuestions.get(i));
			textArea.append("\n");
		}
		textArea.append("\n");
		textArea.append("\n");
		textArea.append("FILL IN THE BLANKS");
		textArea.append("\n");
		textArea.append(fillBlanksS);
	}
	
	public void fillBlanks() {
		int max = (int) Math.floor(ratio*theAnalyzer.arrayNames.size());
		
		textArea.setText(text);
		
		for (int i=0;i<max;i++) {
			//System.out.println(s);
			//String wordToReplace = "\\s"+s+"\\s";
			textArea.setText(textArea.getText().replaceAll(theAnalyzer.arrayNames.get(i),"______"));
			//System.out.println(newText);
		}
		if (ratio > 0.3) {
			textArea.setText(textArea.getText().replaceAll("\\d","_"));
		}
		fillBlanksS = textArea.getText();
		textArea.setText("");
	}
	
	public static void main(String[] args) {
		listQuestions = new ArrayList<>();
		new homeGUI();
	}
	
	private class ButtonListener implements ActionListener {	
		@Override
		/**
		 * Handles the different buttons (add 1, remove 1 or remove all courses)
		 */
		public void actionPerformed(ActionEvent arg0) {
			String actionComm = arg0.getActionCommand();
			if (actionComm.equals("add")) {
				homeGUI.listQuestions.clear();
				JFileChooser chooser = new JFileChooser();
				int returnVal = chooser.showOpenDialog(null); //replace null with your swing container
				File file = new File("test");
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					textArea.setText("");
					theAnalyzer.clean();
					file = chooser.getSelectedFile();  
					BufferedReader in;
					try {
						in = new BufferedReader(new FileReader(file));
						String line;
						try {
							line = in.readLine();
							while(line != null){
								  textArea.append(line + "\n");
								  line = in.readLine();
							}
							text = textArea.getText();
							theAnalyzer.text = textArea.getText();
							theAnalyzer.analyze();
							fillBlanks();
							summary = theAnalyzer.summary();
							theAnalyzer.setUpQuestions();
							fillTextArea();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} else if (actionComm.equals("delete")) {
				textArea.setText("");
				theAnalyzer.clean();
			} else if (actionComm.equals("fill_blanks")) {
				//String newText = theAnalyzer.fillBlanks(textArea.getText());
				//String newText = textArea.getText().replaceAll("\\bWikipedia\\b", "___");
				//System.out.println(newText);
				//textArea.setText("");
				//textArea.setText(newText);
				
				int max = (int) Math.floor(ratio*theAnalyzer.arrayNames.size());
				
				textArea.setText(text);
				
				for (int i=0;i<max;i++) {
					textArea.setText(textArea.getText().replaceAll(theAnalyzer.arrayNames.get(i),"______"));
				}
				if (ratio > 0.3) {
					textArea.setText(textArea.getText().replaceAll("\\d","_"));
				}
				fillBlanksS = textArea.getText();
				textArea.setText("");
			} else if (actionComm.equals("export")) {
				try {
					File file = new File("/Users/damienchambon/Desktop/test1.txt");
					FileWriter fileWriter = new FileWriter(file);
					fileWriter.write(textArea.getText());
					fileWriter.flush();
					fileWriter.close();
					PrintWriter out = new PrintWriter("filename.txt");
					out.println(textArea.getText());
					out.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
