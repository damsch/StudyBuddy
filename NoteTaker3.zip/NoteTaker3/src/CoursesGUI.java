//Damien Chambon - dlc8mt - Homework 5
//Ressources:
//https://docs.oracle.com/javase/tutorial/uiswing/components/combobox.html

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class CoursesGUI extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel title;
	JTextArea creditHours;
	JLabel creditHoursL;
	JTextArea grades;
	JLabel gradesL;
	JTextArea courseName;
	JLabel courseNameL;
	JButton addCourse;
	JButton removeCourse;
	JButton removeAllCourses;
	JComboBox<String> statusCourse;
	JLabel statusCourseL;
	
	/**
	 * Constructor of the Courses GUI, to manage the listCourses (add, remove)
	 */
	public CoursesGUI() {
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		title = new JLabel("Manage your courses");
		title.setFont(new Font("Arial", Font.BOLD, 20));
		
		creditHours = new JTextArea();
		creditHours.setSize(height/4, width/5);
		creditHoursL = new JLabel("Credit Hours :");
		grades = new JTextArea();
		gradesL = new JLabel("Grade (optional) :");
		courseName = new JTextArea();
		courseNameL = new JLabel("Course name (optional) :");
		//We assume the status of the course is mandatory
		statusCourseL = new JLabel("Status of the course: ");
		
		//different statuses of the course
		//we do not let the user add more status
		String[] status = {"Anticipated","Current","Previously taken"};
		statusCourse = new JComboBox<String>(status);
		statusCourse.setEditable(false);
		statusCourse.setSelectedItem(null);
		
		addCourse = new JButton("Add course");
		removeCourse = new JButton("Remove the courses selected");
		removeAllCourses = new JButton("Remove all courses");
		
		//adds all components, and sets their alignement to the center of the gridbox
		this.add(title);
		title.setAlignmentX(CENTER_ALIGNMENT);
		this.add(creditHoursL);
		creditHoursL.setAlignmentX(CENTER_ALIGNMENT);
		this.add(creditHours);
		this.add(gradesL);
		gradesL.setAlignmentX(CENTER_ALIGNMENT);
		this.add(grades);
		this.add(courseNameL);
		courseNameL.setAlignmentX(CENTER_ALIGNMENT);
		this.add(courseName);
		this.add(statusCourseL);
		statusCourseL.setAlignmentX(CENTER_ALIGNMENT);
		this.add(statusCourse);
		this.add(addCourse);
		addCourse.setAlignmentX(CENTER_ALIGNMENT);
		this.add(removeCourse);
		removeCourse.setAlignmentX(CENTER_ALIGNMENT);
		this.add(removeAllCourses);
		removeAllCourses.setAlignmentX(CENTER_ALIGNMENT);
		
		addCourse.setActionCommand("submit");
		addCourse.addActionListener(new ButtonListener());
		removeCourse.setActionCommand("remove");
		removeCourse.addActionListener(new ButtonListener());
		removeCourse.setEnabled(false); //disabled at first since no courses have been added
		removeAllCourses.setActionCommand("removeAll");
		removeAllCourses.addActionListener(new ButtonListener());
		removeAllCourses.setEnabled(false); //disabled at first since no courses have been added
	}
	
	/**
	 * Update the labels and the button of this part of the GUI
	 */
	public void updateLabels() {
		//if (ListCoursesGUI.arrayCourses.size()==0) {
			//no course in the list so cannot remove courses
			removeCourse.setEnabled(false);
			removeAllCourses.setEnabled(false);
		//} else {
			//at least 1 course in the list so can remove courses
			removeCourse.setEnabled(true);
			removeAllCourses.setEnabled(true);
		//}
		creditHours.setText("");
		grades.setText("");
		courseName.setText("");
		statusCourse.setSelectedItem(null);
	}
	
	
	private class ButtonListener implements ActionListener {	
		@Override
		/**
		 * Handles the different buttons (add 1, remove 1 or remove all courses)
		 */
		public void actionPerformed(ActionEvent arg0) {
			String actionComm = arg0.getActionCommand();
			if (actionComm.equals("submit")) {
				if (!(creditHours.getText().equals(""))||(statusCourse.getSelectedItem()==null)) {
					//creates a new Course object, easier to handle, and adds it to the array
					updateLabels();
				} else {
					//1 required field is missing
					JOptionPane.showMessageDialog(null, "Please fill the number of credit hours as well as the status of the course", "Credit hours not added", JOptionPane.ERROR_MESSAGE);
				}
			} else if (actionComm.equals("remove")) {
				//if (index != -1) {
					//no course have been selected to be removed
					//ListCoursesGUI.removeCourse(index);
				//} else {
					JOptionPane.showMessageDialog(null, "Please select one course", "No courses selected ", JOptionPane.ERROR_MESSAGE);
				//}
				updateLabels();
			} else if (actionComm.equals("removeAll")) {
				//ListCoursesGUI.removeAllCourses();
				updateLabels();
			}
			revalidate();
			repaint();
		}
	}
}
