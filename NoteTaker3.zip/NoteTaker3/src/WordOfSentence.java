import com.google.cloud.language.v1.PartOfSpeech.Tag;

public class WordOfSentence {
	String actualWord;
	int type;
	String lem;
	
	public WordOfSentence() {
		this.actualWord = "";
		this.type = 0;
		this.lem = "";
	}
	
	public WordOfSentence(String word, int type, String lem) {
		this.actualWord = word;
		this.type = type;
		this.lem = lem;
	}
	
	public String toString() {
		return "Word: " + this.actualWord + "type: " + this.type + "lem: " + this.lem;
	}
}
