
public class SentenceText implements Comparable<SentenceText> {
	String sentence;
	float salience;
	
	public SentenceText() {
		this.sentence = "";
		this.salience = (float) 0.0;
	}
	
	public SentenceText(String sent) {
		this.sentence = sent;
		this.salience = (float) 0.0;
	}
	
	public SentenceText(String sent, float sal) {
		this.sentence = sent;
		this.salience = sal;
	}
	
	public int compareTo(SentenceText o) {
		if (this.salience<o.salience) return -1;
		if (this.salience>o.salience) {
			return 1;
		} else {
			return 0;
		}
	} 
	
	public String toString() {
		return this.sentence + ": " + this.salience;
	}
	
	public SentenceText copy() {
		SentenceText toReturn = new SentenceText(this.sentence,this.salience);
		return toReturn;
	}
}
