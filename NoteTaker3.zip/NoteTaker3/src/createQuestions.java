
public class createQuestions {
	
	
	
	public createQuestions() {
		
	}
	
	public void makeQuestions(String str) {
		
	}

}
