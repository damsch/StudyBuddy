// Imports the Google Cloud client library
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import com.google.cloud.language.v1.AnalyzeEntitiesRequest;
import com.google.cloud.language.v1.AnalyzeSyntaxRequest;
import com.google.cloud.language.v1.AnalyzeSyntaxResponse;
import com.google.cloud.language.v1.Document;
import com.google.cloud.language.v1.Document.Type;
import com.google.cloud.language.v1.EncodingType;
import com.google.cloud.language.v1.Entity;
import com.google.cloud.language.v1.EntityMention;
import com.google.cloud.language.v1.LanguageServiceClient;
import com.google.cloud.language.v1.Sentiment;
import com.google.cloud.language.v1.Token;
import com.google.cloud.language.v1beta2.AnalyzeEntitiesResponse;

public class Analyzer {
	String text;
	ArrayList<String> arrayNames;
	ArrayList<String> arraySentences;
	ArrayList<String> arraySortedSentences;
	ArrayList<Float> arraySentenceSalience;
	ArrayList<SentenceText> arraySentenceText;
	ArrayList<SentenceText> arraySentenceTextOrdered;
	ArrayList<Float> arraySaliences;
	ArrayList<WordOfSentence> arrayWords;
	Map<String, Float> mapWordSalience = new HashMap<String, Float>();
	//Map<Float, String> mapSalienceSentence = new HashMap<Float, String>();
	
	public Analyzer(String text) {
		this.text = text;
		arrayNames = new ArrayList<>();
		arraySentences = new ArrayList<>();
		arraySentenceSalience = new ArrayList<>();
		arraySortedSentences = new ArrayList<>();
		arraySentenceText = new ArrayList<>();
		arraySentenceTextOrdered = new ArrayList<>();
		arraySaliences = new ArrayList<>();
		arrayWords = new ArrayList<>();
	}
	
	public Analyzer() {
		arrayNames = new ArrayList<>();
		arraySentences = new ArrayList<>();
		arraySentenceSalience = new ArrayList<>();
		arraySortedSentences = new ArrayList<>();
		arraySentenceText = new ArrayList<>();
		arraySentenceTextOrdered = new ArrayList<>();
		arraySaliences = new ArrayList<>();
		arrayWords = new ArrayList<>();
	}
	
	public void clean() {
		this.arrayNames.clear();
		this.arraySentences.clear();
		this.arraySentenceSalience.clear();
		this.mapWordSalience.clear();
		this.arraySortedSentences.clear();
		this.arraySentenceText.clear();
		this.arraySentenceTextOrdered.clear();
		this.arraySaliences.clear();
		this.arrayWords.clear();
	}
	
	public String fillBlanks(String text) {
		String newText = text;
		for (String s: this.arrayNames) {
			String wordToReplace = "\\s"+s+"\\s";
			newText.replace(wordToReplace, "___");
		}
		return newText;
	}
	
	public String summary() {
		String str = "";
		
		for (int i = 0;i < this.arraySentenceText.size();i++) {
			this.arraySaliences.add(this.arraySentenceText.get(i).salience);
		}
		
		float median;
		Collections.sort(this.arraySaliences);
		if (this.arraySaliences.size() % 2 == 0) {
		    median = ((float)this.arraySaliences.get(this.arraySaliences.size()/2) + (float)this.arraySaliences.get((this.arraySaliences.size()/2 - 1)/2));
		} else {
		    median = (float) this.arraySaliences.get(this.arraySaliences.size()/2);
		}
		
		for (int i = 0;i < this.arraySentenceText.size();i++) {
			if (this.arraySentenceText.get(i).salience>=median) {
				str += this.arraySentenceText.get(i).sentence;
			}
		}
		return str;
	}
	
	public void analyzeSentences() {
		BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);
		String source = this.text;
		iterator.setText(source);
		int start = iterator.first();
		for (int end = iterator.next();
		    end != BreakIterator.DONE;
		    start = end, end = iterator.next()) {
			SentenceText sentence = new SentenceText(source.substring(start,end));
			this.arraySentenceText.add(sentence);
		}
		int i = 0;
		for (SentenceText s: this.arraySentenceText) {
			this.arraySentenceSalience.add((float) 0.00);
			Iterator<Entry<String, Float>> it = this.mapWordSalience.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry pair = (Map.Entry)it.next();
		        if (s.sentence.toLowerCase().contains(((String) pair.getKey()).toLowerCase())) {
		        	s.salience+=(Float)pair.getValue();
		        }
		        //it.remove(); // avoids a ConcurrentModificationException
		    }
		    //i++;
		}
		for(SentenceText p : this.arraySentenceText) {
		    this.arraySentenceTextOrdered.add(p.copy());
		}
		Collections.sort(this.arraySentenceTextOrdered,Collections.reverseOrder());
	}
	
	public void setUpQuestions() {
		float median;
		//System.out.println(this.arraySaliences);
		Collections.sort(this.arraySaliences);
		if (this.arraySaliences.size() % 2 == 0) {
		    median = ((float)this.arraySaliences.get(this.arraySaliences.size()/2) + (float)this.arraySaliences.get((this.arraySaliences.size()/2 - 1)/2));
		} else {
		    median = (float) this.arraySaliences.get(this.arraySaliences.size()/2);
		}
		
		for (int i = 0;i < this.arraySentenceText.size();i++) {
			this.arrayWords.clear();
			if (this.arraySentenceText.get(i).salience>=median) {
				String text = this.arraySentenceText.get(i).sentence;
				// Instantiate the Language client com.google.cloud.language.v1.LanguageServiceClient
				  try (LanguageServiceClient language = LanguageServiceClient.create()) {
				    Document doc = Document.newBuilder()
				        .setContent(text)
				        .setType(Type.PLAIN_TEXT)
				        .build();
				    AnalyzeSyntaxRequest request = AnalyzeSyntaxRequest.newBuilder()
				        .setDocument(doc)
				        .setEncodingType(EncodingType.UTF16)
				        .build();
				    // analyze the syntax in the given text
				    AnalyzeSyntaxResponse response = language.analyzeSyntax(request);
				    // print the response
				    for (Token token : response.getTokensList()) {
				  //    System.out.printf("\tText: %s\n", token.getText().getContent());
				  //    System.out.printf("\tBeginOffset: %d\n", token.getText().getBeginOffset());
				    //  System.out.printf("Lemma: %s\n", token.getLemma().toString());
				  //    System.out.printf("PartOfSpeechTag: %s\n", token.getPartOfSpeech().getTag());
				  //    System.out.printf("\tAspect: %s\n", token.getPartOfSpeech().getAspect());
				 //     System.out.printf("\tCase: %s\n", token.getPartOfSpeech().getCase());
				 //     System.out.printf("\tForm: %s\n", token.getPartOfSpeech().getForm());
				 //     System.out.printf("\tGender: %s\n", token.getPartOfSpeech().getGender());
				//      System.out.printf("\tMood: %s\n", token.getPartOfSpeech().getMood());
				//      System.out.printf("\tNumber: %s\n", token.getPartOfSpeech().getNumber());
				//      System.out.printf("\tPerson: %s\n", token.getPartOfSpeech().getPerson());
				//      System.out.printf("\tProper: %s\n", token.getPartOfSpeech().getProper());
				//      System.out.printf("\tReciprocity: %s\n", token.getPartOfSpeech().getReciprocity());
				//      System.out.printf("\tTense: %s\n", token.getPartOfSpeech().getTense());
				//      System.out.printf("\tVoice: %s\n", token.getPartOfSpeech().getVoice());
				      //System.out.println("DependencyEdge");
				      //System.out.printf("\tHeadTokenIndex: %d\n", token.getDependencyEdge().getHeadTokenIndex());
				     // System.out.printf("\tLabel: %s\n\n", token.getDependencyEdge().getLabel());
				      WordOfSentence word = new WordOfSentence();
				      word.actualWord = token.getText().getContent();
				      word.type = token.getPartOfSpeech().getTagValue();
				      word.lem = token.getLemma().toString();
				      this.arrayWords.add(word);
				    }
				    String question = "";
				    question = returnQuestions(this.arrayWords);
				    if (question.equals("")==false) {
				    	homeGUI.listQuestions.add(question);
				    }
				 } catch (Exception e) {
					 
				 }
			}
		
		}
	}
	
  public String returnQuestions(ArrayList<WordOfSentence> arr) {
	String str = "";	
	  for (int i = 0;i<arr.size();i++) {
			if (arr.get(i).type==6) {
				if (arr.get(i+1).lem.equals("be")) {
					str = "What";
					for (int j = i+1;j<arr.size()-1;j++) {
						str += " "+arr.get(j).actualWord;
					}
					str += "?";
				}
			}
		}
	  if (str.equals("") == false) {
		  return str;
	  } else {
		  return "";
	  }
	}

public void analyze() throws Exception {
	  String text = this.text;
    // Instantiates a client
	// Instantiate the Language client com.google.cloud.language.v1.LanguageServiceClient
	  try (LanguageServiceClient language = LanguageServiceClient.create()) {
	    Document doc = Document.newBuilder()
	        .setContent(text)
	        .setType(Type.PLAIN_TEXT)
	        .build();
	    AnalyzeEntitiesRequest request = AnalyzeEntitiesRequest.newBuilder()
	        .setDocument(doc)
	        .setEncodingType(EncodingType.UTF16)
	        .build();

	    com.google.cloud.language.v1.AnalyzeEntitiesResponse response = language.analyzeEntities(request);
	    // Print the response
	    for (Entity entity : response.getEntitiesList()) {
	    	arrayNames.add(entity.getName());
	    	mapWordSalience.put(entity.getName(), entity.getSalience());
	    	//System.out.printf("Entity: %s", entity.getName());
	    	//System.out.printf("Salience: %.3f\n", entity.getSalience());
	    	//System.out.println("Metadata: ");
	    	for (Map.Entry<String, String> entry : entity.getMetadataMap().entrySet()) {
	    		//System.out.printf("%s : %s", entry.getKey(), entry.getValue());
	    	}
	    	for (EntityMention mention : entity.getMentionsList()) {
	    		//System.out.printf("Begin offset: %d\n", mention.getText().getBeginOffset());
	    		//System.out.printf("Content: %s\n", mention.getText().getContent());
	    		//System.out.printf("Type: %s\n\n", mention.getType());
	    	}
	    }
	  }
	    this.analyzeSentences();
	    return;
	  }
 }